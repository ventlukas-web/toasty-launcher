TOASTY LAUNCHER
1. Neues GitHub-Repo (z.B. toasty-launcher), alle Dateien dieses Ordners hochladen (inkl. .github).
2. Actions -> "Build Toasty Launcher" laeuft automatisch. Danach unter Releases "launcher-latest": ToastyLauncher-windows.zip.
3. ZIP entpacken, ToastyLauncher.exe starten.
Anmeldung: Einstellungen -> Azure Client-ID eintragen (eigene App, Mojang muss freigeben) ODER Offline-Modus (nur Singleplayer).
Toasty Client wird nur fuer 1.21.11 geladen (GitHub Release des Client-Repos). Andere Versionen: Fabric + Fabric API, Mods per Modrinth.
Client-Workflow: build.yml legt ein Release "latest" mit der Jar an, damit der Launcher updaten kann.
